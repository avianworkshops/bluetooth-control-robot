# Mobile-Controlled-Bluetooth-Car-Easy-Simple-Hc-05-Motor-Shield
Please SUBSCRIBE To my YouTube channel..........  This the Bluetooth controlled car that used HC-05 Bluetooth module to communicate with mobile.  We can control the car with mobile via Bluetooth.  There is an app to control the motion of car.
